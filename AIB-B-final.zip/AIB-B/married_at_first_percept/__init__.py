from married_at_first_percept.player import Player as Player
